#!/usr/local/anaconda3/bin/python
# This is a Risk calculation module to calculate Variance at Risk for a particular portfolio.
# Given historical data, module provide risk based variance for 90%, 95% and 99% confidence level

import numpy as np
import pandas as pd
import csv

import matplotlib.pyplot as plt
plt.switch_backend('agg')
import seaborn
import matplotlib.mlab as mlab

from scipy.stats import norm
import yfinance as yf

from tabulate import tabulate
from grepfunc import grep_iter

import sys
import getopt

# function to collect historical data
def get_data(Sym):
        INFILE = "/mnt/eoddataset/pricingdata/stockdata.csv"
        OFILE = "ofile.csv"

        infile = open(INFILE, 'r')
        outfile = open(OFILE,"w")

        first_line = infile.readline()
        outfile.write(first_line)

        find_sym = Sym+","

        for symb in grep_iter(infile, find_sym):
                outfile.write(symb)
                outfile.write('\n')

        infile.close()
        outfile.close()

#function to report calculated risk numbers
def report_data(Stock, Var90, Var95, Var99):
        # Each stock symbol will create a seperate file to report the calculation
        RFILE = "/mnt/eoddataset/pricingdata/"+Stock

        rfile = open(RFILE,"w")
        rfile.write(tabulate([['90%', Var90], ['95%', Var95], ['99%', Var99]], headers=['confidence Level', 'value at Risk']))
        rfile.close()


def main(argv):
        try:
                opts, args = getopt.getopt(argv,"hi:o:",["iSym="])

        except getopt.GetoptError:
                print ('risk.py -i <Symbol>')
                sys.exit(2)

        for opt, arg in opts:
                if opt == '-h':
                        print ('risk.py -i <Symbol>')
                        sys.exit()

                elif opt in ("-i", "--iSym"):
                        Symbol = arg

        get_data(Symbol)
        df = pd.read_csv("ofile.csv")
        #df = yf.download('MSFT', '1995-01-31', '2020-01-30')
        df = df[['close']]
        df['returns'] = df.close.pct_change()

        mean = np.mean(df['returns'])
        std_dev = np.std(df['returns'])

        df['returns'].hist(bins=40, density=True, histtype='stepfilled', alpha=0.5)
        x = np.linspace(mean - 3*std_dev, mean + 3*std_dev, 100)
        plt.plot(x, norm.pdf(x, mean, std_dev), "r")
        plt.show()

        VaR_90 = norm.ppf(1-0.9, mean, std_dev)
        VaR_95 = norm.ppf(1-0.95, mean, std_dev)
        VaR_99 = norm.ppf(1-0.99, mean, std_dev)

        report_data(Symbol, VaR_90, VaR_95, VaR_99)

        print(tabulate([['90%', VaR_90], ['95%', VaR_95], ['99%', VaR_99]], headers=['confidence Level', 'value at Risk']))

if __name__ == "__main__":
   main(sys.argv[1:])
