# The following code sample demonstrate a value at risk calculation for a particular stock ticker input. 
# This is derived from the following site: https://blog.quantinsti.com/calculating-value-at-risk-in-excel-python/ and used as a sample.
# Given historical data, we calculate risk based variance for 90%, 95% and 99% confidence level
import sys 
import csv 
from datetime import datetime 
import argparse
import pandas as pd
import numpy as np
from scipy.stats import norm 

def main():
    # The input directory should contain historic stock prices where each stock ticker data is separated into its own file.
    # The output directory is where the VaR calculation will be stored. 
    parser = argparse.ArgumentParser()
    parser.add_argument('-s','--symbol',type=str,required=True,help='Stock symbol for the calculation.')
    parser.add_argument('-o','--output',type=str,required=True,help='Output directory for calculated output file. ex. /mnt/output/')
    parser.add_argument('-i','--input',type=str,required=True,help='Input directory for input stock files. ex: /mnt/pricedata/')
    parser.add_argument('-j','--jobid',type=str,required=False,help='Job ID of batch job to be appended to output file, otherwise defaults to stocksymbol-output-date.csv')
    args = parser.parse_args()

    # Read input csv file based on stock symbol 
    df = pd.read_csv (f'{args.input}{args.symbol.upper()}.csv')
    df = df[['close']]
    
    # Caculate Value at Risk 
    df['returns'] = df.close.pct_change()
    mean = np.mean(df['returns'])
    std_dev = np.std(df['returns'])
    VaR = [
        {'symbol':args.symbol,'confidence-level':'90%','value-at-risk':norm.ppf(1-0.9,mean,std_dev)},
        {'symbol':args.symbol,'confidence-level':'95%','value-at-risk':norm.ppf(1-0.95,mean,std_dev)},
        {'symbol':args.symbol,'confidence-level':'99%','value-at-risk':norm.ppf(1-0.99,mean,std_dev)}
    ]

    # Output results 
    outputfile = f'{args.output}{args.symbol}-{args.jobid}.csv' if args.jobid else f'{args.output}{args.symbol}-{datetime.now().strftime("%m%d%Y-%H%M%S")}.csv'
    with open(outputfile,'w',newline='') as csvfile:
        fieldnames=['symbol','confidence-level','value-at-risk']
        writer = csv.DictWriter(csvfile,fieldnames=fieldnames)
        writer.writeheader()
        [writer.writerow(item) for item in VaR]
    print(f'Value at Risk calculation for {args.symbol} completed and outputted to: {outputfile}')

if __name__ == "__main__": 
    main() 