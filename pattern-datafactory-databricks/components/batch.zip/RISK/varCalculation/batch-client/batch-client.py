# The following batch client was built from the quick start example with some customizations to incorporate app package for risk calculation.
# The python quick start example can be found here: https://github.com/Azure-Samples/batch-python-quickstart 
from __future__ import print_function
import sys
import os
import io
import time 
import random
import datetime
import azure.storage.blob as azureblob 
import azure.batch.batch_service_client as batch 
import azure.batch.batch_auth as batch_auth
import azure.batch.models as batchmodels
import config
try:
    input = raw_input
except NameError: 
    pass 

# Commands to prep node for risk calculation run and Azure file mount
def get_start_task_cmds(): 
    cmds = []
    cmds.append('apt-get update && apt-get install -y python3-pip')
    cmds.append('python3 -m pip install -r $AZ_BATCH_APP_PACKAGE_varcalculation_0_1/requirements.txt')
    cmds.append(f'apt-get install cifs-utils && mkdir -p {config._COMPUTE_NODE_MOUNT_POINT} && mount -t cifs {config._STORAGE_ACCOUNT_SHARE_ENDPOINT} {config._COMPUTE_NODE_MOUNT_POINT} -o vers=3.0,username={config. _STORAGE_ACCOUNT_NAME},password={config._STORAGE_ACCOUNT_KEY},dir_mode=0777,file_mode=0777,serverino')
    cmdstr = ' && '.join(cmds)
    return f'/bin/bash -c "{cmdstr}"'

# Create pool function 
def create_pool(batch_service_client, pool_id, start_tasks, app_pkg):
    if batch_service_client.pool.exists(pool_id=pool_id): 
        print(f'Batch pool with id {pool_id} already exists. A new pool will not be provisioned.')
    else: 
        print(f'Creating pool [{pool_id}]...')
        new_pool = batch.models.PoolAddParameter(
            id=pool_id,
            virtual_machine_configuration=batchmodels.VirtualMachineConfiguration(
                image_reference=batchmodels.ImageReference(
                    publisher="Canonical",
                    offer="UbuntuServer",
                    sku="18.04-LTS",
                    version="latest"
                ),
                node_agent_sku_id="batch.node.ubuntu 18.04"),
            vm_size=config._POOL_VM_SIZE,
            target_dedicated_nodes=config._POOL_NODE_COUNT,
            max_tasks_per_node=4,
            application_package_references= app_pkg, 
            start_task=batchmodels.StartTask(
            command_line=start_tasks,
            wait_for_success=True,
            user_identity=batchmodels.UserIdentity(
                auto_user=batchmodels.AutoUserSpecification(
                    scope=batchmodels.AutoUserScope.pool,
                    elevation_level=batchmodels.ElevationLevel.admin))
            )
        )
        batch_service_client.pool.add(new_pool)

# Crete job function
def create_job(batch_service_client, job_id, pool_id):
    print(f'Creating job [{job_id}]...')
    job = batch.models.JobAddParameter(
        id=job_id,
        pool_info=batch.models.PoolInformation(pool_id=pool_id))
    batch_service_client.job.add(job)

# Create task function 
# The var calc package is located at AZ_BATCH_APP_PACKAGE_appid_version# and is hard-coded below, but likewise can be parameterized as needed. 
def add_tasks(batch_service_client, job_id, stockSymbols, inputDirectory, outputDirectory):
    print(f'Adding {len(stockSymbols)} tasks to job [{job_id}]...')
    tasks = list()
    for idx, stockSymbol in enumerate(stockSymbols):
        command = f'/bin/bash -c "python3 $AZ_BATCH_APP_PACKAGE_varcalculation_0_1/riskCalc.py -s {stockSymbol} -i {inputDirectory} -o {outputDirectory} -j {job_id}"'
        tasks.append(
            batch.models.TaskAddParameter(
                id=f'Task{idx}',
                command_line=command
            )
        )
    batch_service_client.task.add_collection(job_id, tasks)

# Wait for task function
def wait_for_tasks_to_complete(batch_service_client, job_id, timeout):
    timeout_expiration = datetime.datetime.now() + timeout
    print(f'Monitoring all tasks for "Completed" state, timeout in {timeout}...')
    while datetime.datetime.now() < timeout_expiration:
        print('.', end='')
        sys.stdout.flush()
        tasks = batch_service_client.task.list(job_id)
        incomplete_tasks = [task for task in tasks if
                            task.state != batchmodels.TaskState.completed]
        if not incomplete_tasks:
            print()
            return True
        else:
            time.sleep(1)
    print()
    raise RuntimeError("ERROR: Tasks did not reach 'Completed' state within "
                       "timeout period of " + str(timeout))

# Print task output function
def print_task_output(batch_service_client, job_id, encoding=None):
    print('Printing task output...')
    tasks = batch_service_client.task.list(job_id)
    for task in tasks:
        node_id = batch_service_client.task.get(
            job_id, task.id).node_info.node_id
        print(f'Task: {task.id}')
        print(f'Node: {node_id}')
        stream = batch_service_client.file.get_from_task(
            job_id, task.id, config._STANDARD_OUT_FILE_NAME)
        file_text = _read_stream_as_string(
            stream,
            encoding)
        print("Standard output:")
        print(file_text)

def _read_stream_as_string(stream, encoding):
    output = io.BytesIO()
    try:
        for data in stream:
            output.write(data)
        if encoding is None:
            encoding = 'utf-8'
        return output.getvalue().decode(encoding)
    finally:
        output.close()
    raise RuntimeError('could not write data to stream or decode bytes')

def query_yes_no(question, default="yes"):
    valid = {'y': 'yes', 'n': 'no'}
    if default is None:
        prompt = ' [y/n] '
    elif default == 'yes':
        prompt = ' [Y/n] '
    elif default == 'no':
        prompt = ' [y/N] '
    else:
        raise ValueError(f'Invalid default answer: "{default}"')

    while 1:
        choice = input(question + prompt).lower()
        if default and not choice:
            return default
        try:
            return valid[choice[0]]
        except (KeyError, IndexError):
            print("Please respond with 'yes' or 'no' (or 'y' or 'n').\n")

# Print batch exception error
def print_batch_exception(batch_exception):
    print('-------------------------------------------')
    print('Exception encountered:')
    if batch_exception.error and \
            batch_exception.error.message and \
            batch_exception.error.message.value:
        print(batch_exception.error.message.value)
        if batch_exception.error.values:
            print()
            for mesg in batch_exception.error.values:
                print(f'{mesg.key}:\t{mesg.value}')
    print('-------------------------------------------')

if __name__ == '__main__': 
    start_time = datetime.datetime.now().replace(microsecond=0)
    print(f'Client run started at: {start_time}')

    # Stock tickers to do value at risk calculation for
    stockSymbols = ['A','AAL','AAPL','ACN','ADP','AXP','BA','BDX','BMY','BSX','CAT','CB',
                    'CSCO','CVX','DIS','DOW','GD','GE','GS','H','HD','IBM','INTC','JNJ','JPM',
                    'KO','LH','LMT','MA','MCD','MMM','MRK','MS','MSFT','NKE','PFE','PG','TRV',
                    'UN','UTX','V','VZ','WBA','WMT','XOM']

    # Create batch service client 
    credentials = batch_auth.SharedKeyCredentials(config._BATCH_ACCOUNT_NAME,config._BATCH_ACCOUNT_KEY)
    batch_client = batch.BatchServiceClient(
        credentials, 
        batch_url=config._BATCH_ACCOUNT_URL
    )

    # Create random id to be used for the job run
    _JOB_ID = f'riskcalc{datetime.datetime.now().strftime("%d%m%Y%H%M%S")}'

    try: 
        # Create the pool that will contain the compute nodes to execute the risk calculation tasks
        app_pkg = [batch.models.ApplicationPackageReference(application_id='varcalculation',version='0.1')]
        create_pool(batch_client, config._POOL_ID, get_start_task_cmds(), app_pkg)

        # Create the job that will run the tasks 
        create_job(batch_client, _JOB_ID, config._POOL_ID)

        # Add tasks to the job 
        add_tasks(batch_client, _JOB_ID, stockSymbols, f'{config._COMPUTE_NODE_MOUNT_POINT}/pricingdata/',f'{config._COMPUTE_NODE_MOUNT_POINT}/outputdata/')

        # Pause execution until task reach completed state 
        wait_for_tasks_to_complete(batch_client, _JOB_ID, datetime.timedelta(minutes=30))
        print(f"Completed job: {_JOB_ID}. All task reached the completed state within specified timeout period.")
        
        # Print the stdout.txt and stderr.txt files for each task to console
        print_task_output(batch_client, _JOB_ID)

        # Clean up batch resources (if needed)
        if query_yes_no('Delete job?') == 'yes':
            batch_client.job.delete(_JOB_ID)
        if query_yes_no('Delete pool?') == 'yes': 
            batch_client.pool.delete(config._POOL_ID)

    except batchmodels.BatchErrorException as err: 
        print_batch_exception(err)
        raise 

    end_time = datetime.datetime.now().replace(microsecond=0)
    print(f'Client run ended at: {end_time}')
    print(f'Elapsed time: {end_time - start_time}')
