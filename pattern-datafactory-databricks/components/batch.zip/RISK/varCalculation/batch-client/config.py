# -------------------------------------------------------------------------
# THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
# EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
# OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
# ----------------------------------------------------------------------------------
# The example companies, organizations, products, domain names,
# e-mail addresses, logos, people, places, and events depicted
# herein are fictitious. No association with any real company,
# organization, product, domain name, email address, logo, person,
# places, or events is intended or should be inferred.
# --------------------------------------------------------------------------
# Global constant variables (Azure Storage account/Batch details)

_COMPUTE_NODE_MOUNT_POINT = '/mnt/batchshare'
_STORAGE_ACCOUNT_SHARE_ENDPOINT = '//eoddataset.file.core.windows.net/pricingdata'
_BATCH_ACCOUNT_NAME = 'risk'  # Your batch account name
_BATCH_ACCOUNT_KEY = 'oacIQPP1WyBBWpI5hBa9Uf0zQDZsEl9s31FFgxeVUaffoZLZYD6GdVStOyEQiP2TBRG3cyotj8GgbWNE5XdjVQ=='  # Your batch account key
_BATCH_ACCOUNT_URL = 'https://risk.eastus2.batch.azure.com'  # Your batch account URL
_STORAGE_ACCOUNT_NAME = 'eoddataset'  # Your storage account name
_STORAGE_ACCOUNT_KEY = 'JxeUCv2YYB/XCX40fjj89ui8DqpTXAB3sW+GIylc5DOMNC4wrXBXYyAnbt7L7eQI7ZOcgkSwmyEkuznZ7bTXBw=='  # Your storage account key
_POOL_ID = 'RiskPoolVM5'  # Your Pool ID
_POOL_NODE_COUNT = 2  # Pool node count
_POOL_VM_SIZE = 'STANDARD_d2_v2'  # VM Type/Size
_JOB_ID = ''  # Job ID
_STANDARD_OUT_FILE_NAME = 'stdout.txt'  # Standard Output file